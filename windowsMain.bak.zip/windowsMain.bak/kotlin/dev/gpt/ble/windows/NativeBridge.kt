package dev.gpt.ble.windows

import java.nio.file.Files

internal class NativeBridge(private val owner: WindowsBleManager) {
    init { NativeLibrary.load() }
    external fun create(): Long
    external fun destroy(manager: Long)
    external fun adapterState(manager: Long): Int
    external fun pairingState(manager: Long, address: String, addressType: Int): Int
    external fun pair(manager: Long, address: String, addressType: Int, timeoutMillis: Long): Int
    external fun unpair(manager: Long, address: String, addressType: Int, timeoutMillis: Long): Int
    external fun startScan(manager: Long, generation: Long)
    external fun stopScan(manager: Long)
    external fun connect(manager: Long, address: String, addressType: Int, timeoutMillis: Long): Long
    external fun monitor(manager: Long, connection: Long): Boolean
    external fun disconnect(manager: Long, connection: Long)
    external fun discover(manager: Long, connection: Long): Array<String>
    external fun readDeviceName(manager: Long, connection: Long): ByteArray?
    external fun read(manager: Long, connection: Long, attribute: Int, descriptor: Boolean): ByteArray
    external fun write(manager: Long, connection: Long, attribute: Int, descriptor: Boolean, value: ByteArray, withResponse: Boolean)
    external fun subscribe(manager: Long, connection: Long, attribute: Int, mode: Int)
    external fun mtu(manager: Long, connection: Long): Int

    @Suppress("unused")
    private fun onAdvertisement(generation: Long, address: String, name: String?, rssi: Int, addressType: Int,
                                connectable: Boolean, completeName: Boolean, services: Array<String>, manufacturer: Array<ByteArray>) =
        owner.advertisement(generation, address, name, rssi, addressType, connectable, completeName, services, manufacturer)
    @Suppress("unused")
    private fun onScanStopped(generation: Long, error: String?) = owner.scanStopped(generation, error)
    @Suppress("unused")
    private fun onKnownDevice(generation: Long, address: String, name: String?) = owner.knownDevice(generation, address, name)
    @Suppress("unused")
    private fun onNameLookupFailed(generation: Long, message: String) = owner.nameLookupFailed(generation, message)
    @Suppress("unused")
    private fun onDisconnected(connection: Long, error: String) = owner.disconnected(connection, error)
    @Suppress("unused")
    private fun onNotification(connection: Long, attribute: Int, value: ByteArray) = owner.notification(connection, attribute, value)
    @Suppress("unused")
    private fun onMtuChanged(connection: Long, mtu: Int) = owner.mtuChanged(connection, mtu)
    @Suppress("unused")
    private fun onAdapterStateChanged(state: Int) = owner.adapterChanged(state)
}

private object NativeLibrary {
    private var loaded = false
    @Synchronized fun load() {
        if (loaded) return
        require(System.getProperty("os.name").startsWith("Windows", true)) { "WindowsBleManager requires Windows" }
        require(System.getProperty("os.arch") in setOf("amd64", "x86_64")) { "This build contains the Windows x64 native library" }
        val stream = NativeLibrary::class.java.getResourceAsStream("/natives/windows-x64/gpt-ble-windows.dll")
            ?: throw UnsatisfiedLinkError("gpt-ble-windows.dll is missing; build the Windows artifact on Windows")
        val dll = Files.createTempFile("gpt-ble-windows-", ".dll").toFile()
        dll.deleteOnExit()
        stream.use { input -> dll.outputStream().use { input.copyTo(it) } }
        System.load(dll.absolutePath)
        loaded = true
    }
}
