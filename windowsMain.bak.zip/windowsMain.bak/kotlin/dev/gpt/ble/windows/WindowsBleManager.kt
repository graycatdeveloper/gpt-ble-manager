package dev.gpt.ble.windows

import dev.gpt.ble.*
import dev.gpt.ble.internal.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.concurrent.ConcurrentHashMap

class WindowsBleManager : BleManager {
    private val lock = Any()
    private val native = NativeBridge(this)
    @Volatile private var handle = native.create()
    private var generation = 0L
    private var scan: ScanStore? = null
    private val adapters = MutableStateFlow(AdapterState.PoweredOff)
    private val scanning = MutableStateFlow(ScanState())
    private val found = MutableStateFlow<List<BleDevice>>(emptyList())
    override val adapterState = adapters.asStateFlow()
    override val scanState = scanning.asStateFlow()
    override val devices = found.asStateFlow()
    private val connections = ConcurrentHashMap<Long, WindowsConnection>()
    private val addresses = ConcurrentHashMap.newKeySet<String>()

    private fun activeHandle(): Long = handle.takeIf { it != 0L } ?: throw BleException(BleError.Closed, "Manager is closed")

    override suspend fun refreshAdapterState(): AdapterState = withContext(Dispatchers.IO) {
        if (handle == 0L) AdapterState.Closed else when (native.adapterState(activeHandle())) {
            0 -> AdapterState.Ready
            1 -> AdapterState.PoweredOff
            2 -> AdapterState.PermissionRequired
            else -> AdapterState.Unsupported
        }
    }.let { result -> synchronized(lock) {
        (if (handle == 0L) AdapterState.Closed else result).also { adapters.value = it }
    } }

    override suspend fun getPairingState(device: BleDevice): PairingState = withContext(Dispatchers.IO) {
        val manager = activeHandle()
        val address = canonicalAddress(device.address)
        try {
            val result = native.pairingState(manager, address, device.addressType.ordinal)
            activeHandle()
            when (result) {
                0 -> PairingState.NotPaired
                1 -> PairingState.Paired
                else -> PairingState.Unknown
            }
        } catch (e: IllegalStateException) {
            throw e.asBleException("Unable to read Windows pairing state")
        }
    }

    override suspend fun pair(device: BleDevice, timeoutMillis: Long): PairResult = changePairing(device, timeoutMillis) { manager, address ->
        pairResult(native.pair(manager, address, device.addressType.ordinal, timeoutMillis))
    }

    override suspend fun unpair(device: BleDevice, timeoutMillis: Long): UnpairResult = changePairing(device, timeoutMillis) { manager, address ->
        unpairResult(native.unpair(manager, address, device.addressType.ordinal, timeoutMillis))
    }

    private suspend fun <T> changePairing(device: BleDevice, timeoutMillis: Long, operation: (Long, String) -> T): T {
        require(timeoutMillis in 1..120_000)
        val manager = activeHandle()
        val address = canonicalAddress(device.address)
        // Also reserves the address against a concurrent connect/unpair on this manager.
        if (!addresses.add(address)) throw BleException(BleError.Rejected,
            "Close the connection to $address and wait for pending operations before changing pairing")
        try {
            return withContext(Dispatchers.IO) {
                operation(manager, address)
            }
        } catch (e: IllegalStateException) {
            throw e.asBleException("Windows pairing operation failed")
        } finally {
            addresses.remove(address)
        }
    }

    override suspend fun startScan(options: ScanOptions) {
        val state = refreshAdapterState()
        if (state != AdapterState.Ready) throw BleException(BleError.NotReady, "Bluetooth adapter is $state")
        synchronized(lock) {
            stopScan()
            val manager = activeHandle()
            scan = ScanStore(options)
            found.value = emptyList()
            scanning.value = ScanState(scanning = true)
            try { native.startScan(manager, ++generation) }
            catch (e: Exception) {
                scan = null
                val error = BleException(BleError.NativeFailure, "Unable to start Windows scan", e)
                scanning.value = ScanState(error = error)
                throw error
            }
        }
    }

    override fun stopScan() = synchronized(lock) {
        generation++
        try {
            if (handle != 0L) native.stopScan(handle)
            scanning.value = scanning.value.copy(scanning = false)
        } catch (e: IllegalStateException) {
            scanning.value = ScanState(error = BleException(BleError.NativeFailure, "Unable to stop Windows scan", e))
        }
    }

    override suspend fun connect(device: BleDevice, timeoutMillis: Long): BleConnection {
        require(timeoutMillis in 1..120_000)
        val address = canonicalAddress(device.address)
        val manager = activeHandle()
        if (!addresses.add(address)) throw BleException(BleError.Rejected, "A connection to $address already exists")
        var session = 0L
        var connection: WindowsConnection? = null
        try {
            withContext(Dispatchers.IO) { session = native.connect(manager, address, device.addressType.ordinal, timeoutMillis) }
            currentCoroutineContext().ensureActive()
            connection = WindowsConnection(native, manager, session, device.copy(address = address),
                onDeviceName = { name -> updateGattName(address, name) }) {
                connections.remove(session)
                addresses.remove(address)
            }
            connections[session] = connection
            if (handle == 0L || !native.monitor(manager, session)) {
                throw BleException(BleError.Disconnected, "Device disconnected during connection setup")
            }
            connection.connected()
            return connection
        } catch (e: Throwable) {
            if (connection != null) connection.close() else if (session != 0L) runCatching { native.disconnect(manager, session) }
            addresses.remove(address)
            if (e is IllegalStateException) throw e.asBleException("Windows connection failed")
            throw e
        }
    }

    override fun close() {
        val previous = synchronized(lock) {
            if (handle == 0L) return
            stopScan()
            handle.also { handle = 0L }
        }
        connections.values.toList().forEach { it.close() }
        native.destroy(previous)
        adapters.value = AdapterState.Closed
    }

    internal fun advertisement(token: Long, address: String, name: String?, rssi: Int, addressType: Int,
                               connectable: Boolean, completeName: Boolean, services: Array<String>, manufacturer: Array<ByteArray>) = synchronized(lock) {
        if (token != generation || handle == 0L || !scanning.value.scanning) return@synchronized
        val store = scan ?: return@synchronized
        val mfr = manufacturer.filter { it.size >= 2 }.associate { bytes ->
            ((bytes[0].toInt() and 255) or ((bytes[1].toInt() and 255) shl 8)) to BleBytes(bytes.copyOfRange(2, bytes.size))
        }
        store.accept(Advertisement(BleDevice(address, name, rssi, AddressType.entries.getOrElse(addressType) { AddressType.Unknown },
            connectable, services.map { BleUuid.parse(it) }.toSet(), mfr), completeName))
        found.value = store.devices.value
    }

    internal fun scanStopped(token: Long, error: String?) = synchronized(lock) {
        if (token != generation) return@synchronized
        scanning.value = scanning.value.copy(scanning = false, error = error?.let { BleException(BleError.NativeFailure, it) })
    }
    internal fun knownDevice(token: Long, address: String, name: String?) = synchronized(lock) {
        if (token != generation || handle == 0L || !scanning.value.scanning) return@synchronized
        val store = scan ?: return@synchronized
        store.rememberSystemDevice(BleDevice(address, name))
        found.value = store.devices.value
    }
    internal fun nameLookupFailed(token: Long, message: String) = synchronized(lock) {
        if (token != generation || handle == 0L || !scanning.value.scanning) return@synchronized
        scanning.value = scanning.value.copy(nameResolutionError = BleException(BleError.NativeFailure, message))
    }
    private fun updateGattName(address: String, name: String) = synchronized(lock) {
        if (handle == 0L) return@synchronized
        scan?.let { it.updateGattName(address, name); found.value = it.devices.value }
    }
    internal fun disconnected(session: Long, error: String) {
        connections[session]?.terminate(BleException(BleError.Disconnected, error))
    }
    internal fun notification(session: Long, attribute: Int, value: ByteArray) { connections[session]?.notification(attribute, value) }
    internal fun mtuChanged(session: Long, mtu: Int) { connections[session]?.mtuChanged(mtu) }
    internal fun adapterChanged(state: Int) {
        if (handle == 0L) return
        adapters.value = if (state == 0) AdapterState.Ready else AdapterState.PoweredOff
        if (state != 0) {
            stopScan()
            connections.values.toList().forEach { it.terminate(BleException(BleError.NotReady, "Bluetooth adapter was turned off")) }
        }
    }
}
