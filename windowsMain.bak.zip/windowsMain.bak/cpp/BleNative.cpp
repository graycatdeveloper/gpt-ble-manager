#include <jni.h>
#include <windows.h>
#include <roapi.h>
#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.Foundation.Collections.h>
#include <winrt/Windows.Devices.Bluetooth.h>
#include <winrt/Windows.Devices.Bluetooth.Advertisement.h>
#include <winrt/Windows.Devices.Bluetooth.GenericAttributeProfile.h>
#include <winrt/Windows.Devices.Radios.h>
#include <winrt/Windows.Devices.Enumeration.h>
#include <winrt/Windows.Storage.Streams.h>
#include <atomic>
#include <algorithm>
#include <chrono>
#include <map>
#include <memory>
#include <mutex>
#include <sstream>
#include <iomanip>
#include <stdexcept>
#include <vector>

using namespace winrt;
using namespace winrt::Windows::Foundation;
using namespace winrt::Windows::Devices::Bluetooth;
using namespace winrt::Windows::Devices::Bluetooth::Advertisement;
using namespace winrt::Windows::Devices::Bluetooth::GenericAttributeProfile;
using namespace winrt::Windows::Devices::Radios;
using namespace winrt::Windows::Devices::Enumeration;
using namespace winrt::Windows::Storage::Streams;
using Clock = std::chrono::steady_clock;

namespace {
struct Apartment {
    HRESULT result = RoInitialize(RO_INIT_MULTITHREADED);
    Apartment() { if (FAILED(result) && result != RPC_E_CHANGED_MODE) check_hresult(result); }
    ~Apartment() { if (SUCCEEDED(result)) RoUninitialize(); }
};
void apartment() { thread_local Apartment current; }

template<typename T> auto await(T const& operation, Clock::time_point deadline) {
    auto remaining = deadline - Clock::now();
    if (remaining <= Clock::duration::zero() || operation.wait_for(std::chrono::duration_cast<TimeSpan>(remaining)) == AsyncStatus::Started) {
        operation.Cancel();
        throw std::runtime_error("TIMEOUT: Windows Bluetooth operation timed out");
    }
    return operation.GetResults();
}
Clock::time_point deadline() { return Clock::now() + std::chrono::seconds(12); }

struct GattFailure : std::runtime_error {
    GattCommunicationStatus status;
    GattFailure(GattCommunicationStatus value, std::string const& message) : std::runtime_error(message), status(value) {}
};

void success(GattCommunicationStatus status, std::string const& context = "GATT operation") {
    if (status != GattCommunicationStatus::Success) {
        const auto reason = status == GattCommunicationStatus::AccessDenied ? "AccessDenied" :
            status == GattCommunicationStatus::Unreachable ? "Unreachable" :
            status == GattCommunicationStatus::ProtocolError ? "ProtocolError" : "Unknown";
        throw GattFailure(status, context + " failed: " + reason + " (status=" + std::to_string(static_cast<int>(status)) + ")");
    }
}

struct JavaEnv {
    JavaVM* vm;
    JNIEnv* env = nullptr;
    bool attached = false;
    explicit JavaEnv(JavaVM* value) : vm(value) {
        if (vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) == JNI_EDETACHED) {
            attached = vm->AttachCurrentThreadAsDaemon(reinterpret_cast<void**>(&env), nullptr) == JNI_OK;
        }
    }
    ~JavaEnv() { if (attached) vm->DetachCurrentThread(); }
};

jstring text(JNIEnv* env, std::wstring_view value) {
    static_assert(sizeof(wchar_t) == sizeof(jchar));
    return env->NewString(reinterpret_cast<const jchar*>(value.data()), static_cast<jsize>(value.size()));
}
std::wstring text(JNIEnv* env, jstring value) {
    if (!value) return {};
    auto chars = env->GetStringChars(value, nullptr);
    if (!chars) throw std::bad_alloc();
    std::wstring result(reinterpret_cast<const wchar_t*>(chars), env->GetStringLength(value));
    env->ReleaseStringChars(value, chars);
    return result;
}
std::vector<uint8_t> bytes(IBuffer const& buffer) {
    std::vector<uint8_t> result(buffer.Length());
    if (!result.empty()) DataReader::FromBuffer(buffer).ReadBytes(result);
    return result;
}
IBuffer buffer(JNIEnv* env, jbyteArray value) {
    std::vector<uint8_t> data(env->GetArrayLength(value));
    if (!data.empty()) env->GetByteArrayRegion(value, 0, static_cast<jsize>(data.size()), reinterpret_cast<jbyte*>(data.data()));
    DataWriter writer;
    writer.WriteBytes(data);
    return writer.DetachBuffer();
}
jbyteArray byteArray(JNIEnv* env, const std::vector<uint8_t>& value) {
    auto result = env->NewByteArray(static_cast<jsize>(value.size()));
    if (result && !value.empty()) env->SetByteArrayRegion(result, 0, static_cast<jsize>(value.size()), reinterpret_cast<const jbyte*>(value.data()));
    return result;
}
jobjectArray strings(JNIEnv* env, const std::vector<std::wstring>& values) {
    auto cls = env->FindClass("java/lang/String");
    auto result = env->NewObjectArray(static_cast<jsize>(values.size()), cls, nullptr);
    for (size_t i = 0; result && i < values.size(); ++i) {
        auto value = text(env, values[i]);
        env->SetObjectArrayElement(result, static_cast<jsize>(i), value);
        env->DeleteLocalRef(value);
    }
    env->DeleteLocalRef(cls);
    return result;
}
std::wstring uuid(guid const& value) {
    std::wstring result = to_hstring(value).c_str();
    if (!result.empty() && result.front() == L'{') result = result.substr(1, result.size() - 2);
    return result;
}
std::wstring addressString(uint64_t address) {
    std::wostringstream result;
    result << std::hex << std::uppercase << std::setfill(L'0');
    for (int shift = 40; shift >= 0; shift -= 8) {
        if (shift != 40) result << L':';
        result << std::setw(2) << ((address >> shift) & 255);
    }
    return result.str();
}

struct Manager;
struct Connection {
    jlong id = 0;
    std::weak_ptr<Manager> manager;
    BluetoothLEDevice device{nullptr};
    GattSession session{nullptr};
    std::mutex mutex;
    std::atomic<bool> closed{false};
    std::atomic<bool> catalogReady{false};
    std::vector<GattDeviceService> services;
    std::map<int, GattCharacteristic> characteristics;
    std::map<int, GattDescriptor> descriptors;
    std::map<int, std::pair<GattCharacteristic, event_token>> notifications;
    event_token statusToken{}, mtuToken{}, servicesToken{};

    void close() noexcept {
        if (closed.exchange(true)) return;
        std::map<int, std::pair<GattCharacteristic, event_token>> oldNotifications;
        std::vector<GattDeviceService> oldServices;
        event_token oldStatus{}, oldMtu{}, oldChanged{};
        {
            std::lock_guard lock(mutex);
            oldNotifications.swap(notifications);
            oldServices.swap(services);
            oldStatus = statusToken; oldMtu = mtuToken; oldChanged = servicesToken;
            statusToken = {}; mtuToken = {}; servicesToken = {};
            characteristics.clear(); descriptors.clear();
        }
        try {
            for (auto& [_, entry] : oldNotifications) entry.first.ValueChanged(entry.second);
            if (device && oldStatus.value) device.ConnectionStatusChanged(oldStatus);
            if (device && oldChanged.value) device.GattServicesChanged(oldChanged);
            if (session && oldMtu.value) session.MaxPduSizeChanged(oldMtu);
            for (auto& service : oldServices) { try { service.Close(); } catch (...) { } }
            if (session) {
                try { session.MaintainConnection(false); } catch (...) { }
                try { session.Close(); } catch (...) { }
            }
            if (device) { try { device.Close(); } catch (...) { } }
        } catch (...) { /* Best effort during teardown; no native exception crosses JNI. */ }
    }
    ~Connection() { close(); }
};

struct Manager : std::enable_shared_from_this<Manager> {
    JavaVM* vm = nullptr;
    jobject callback = nullptr;
    jmethodID advertisement{}, scanStopped{}, knownDevice{}, nameLookupFailed{}, disconnected{}, notification{}, mtuChanged{}, adapterChanged{};
    std::mutex mutex;
    std::atomic<bool> closed{false};
    BluetoothLEAdvertisementWatcher watcher{nullptr};
    event_token receivedToken{}, stoppedToken{};
    DeviceWatcher nameWatcher{nullptr};
    event_token addedToken{}, updatedToken{}, removedToken{}, namesStoppedToken{};
    Radio radio{nullptr};
    event_token radioToken{};
    std::map<jlong, std::shared_ptr<Connection>> connections;

    template<typename F> void call(F function) noexcept {
        if (closed.load()) return;
        JavaEnv attachment(vm);
        auto env = attachment.env;
        if (!env || env->PushLocalFrame(64) != JNI_OK) return;
        try { function(env); }
        catch (...) { OutputDebugStringW(L"GPT BLE: native event callback failed\n"); }
        if (env->ExceptionCheck()) { env->ExceptionDescribe(); env->ExceptionClear(); }
        env->PopLocalFrame(nullptr);
    }
    void stop() {
        BluetoothLEAdvertisementWatcher old{nullptr};
        event_token received{}, stopped{};
        DeviceWatcher oldNames{nullptr};
        event_token added{}, updated{}, removed{}, namesStopped{};
        {
            std::lock_guard lock(mutex);
            old = watcher; watcher = nullptr;
            received = receivedToken; stopped = stoppedToken;
            receivedToken = {}; stoppedToken = {};
            oldNames = nameWatcher; nameWatcher = nullptr;
            added = addedToken; updated = updatedToken; removed = removedToken; namesStopped = namesStoppedToken;
            addedToken = {}; updatedToken = {}; removedToken = {}; namesStoppedToken = {};
        }
        if (old) {
            if (received.value) old.Received(received);
            if (stopped.value) old.Stopped(stopped);
            if (old.Status() == BluetoothLEAdvertisementWatcherStatus::Started) old.Stop();
        }
        if (oldNames) {
            if (added.value) oldNames.Added(added);
            if (updated.value) oldNames.Updated(updated);
            if (removed.value) oldNames.Removed(removed);
            if (namesStopped.value) oldNames.Stopped(namesStopped);
            auto status = oldNames.Status();
            if (status == DeviceWatcherStatus::Started || status == DeviceWatcherStatus::EnumerationCompleted) oldNames.Stop();
        }
    }
    void close() noexcept {
        if (closed.exchange(true)) return;
        try { stop(); } catch (...) { }
        std::map<jlong, std::shared_ptr<Connection>> old;
        Radio oldRadio{nullptr};
        event_token oldRadioToken{};
        { std::lock_guard lock(mutex); old.swap(connections); oldRadio = radio; oldRadioToken = radioToken; radio = nullptr; radioToken = {}; }
        if (oldRadio && oldRadioToken.value) oldRadio.StateChanged(oldRadioToken);
        for (auto& [_, connection] : old) connection->close();
    }
    ~Manager() {
        close();
        JavaEnv attachment(vm);
        if (attachment.env && callback) attachment.env->DeleteGlobalRef(callback);
    }
};

std::mutex registryMutex;
std::map<jlong, std::shared_ptr<Manager>> managers;
std::atomic<jlong> nextId{1};

std::shared_ptr<Manager> manager(jlong handle) {
    std::lock_guard lock(registryMutex);
    auto it = managers.find(handle);
    if (it == managers.end() || it->second->closed.load()) throw std::runtime_error("Manager is closed");
    return it->second;
}
std::shared_ptr<Connection> connection(jlong handle, jlong id) {
    auto owner = manager(handle);
    std::lock_guard lock(owner->mutex);
    auto it = owner->connections.find(id);
    if (it == owner->connections.end() || it->second->closed.load()) throw std::runtime_error("Connection is closed");
    return it->second;
}
void failure(JNIEnv* env) noexcept {
    if (env->ExceptionCheck()) return;
    std::wstring message;
    jint gattStatus = -1;
    try { throw; }
    catch (GattFailure const& error) { message = to_hstring(error.what()).c_str(); gattStatus = static_cast<jint>(error.status); }
    catch (hresult_error const& error) { message = error.message().c_str(); }
    catch (std::exception const& error) { message = to_hstring(error.what()).c_str(); }
    catch (...) { message = L"Unknown Windows Bluetooth failure"; }
    auto cls = env->FindClass(gattStatus >= 0 ? "dev/gpt/ble/windows/WindowsGattException" : "java/lang/IllegalStateException");
    if (!cls) return;
    auto constructor = env->GetMethodID(cls, "<init>", gattStatus >= 0 ? "(ILjava/lang/String;)V" : "(Ljava/lang/String;)V");
    if (!constructor) { env->DeleteLocalRef(cls); return; }
    auto msg = text(env, message);
    auto error = static_cast<jthrowable>(gattStatus >= 0 ?
        env->NewObject(cls, constructor, gattStatus, msg) : env->NewObject(cls, constructor, msg));
    if (error) env->Throw(error);
    env->DeleteLocalRef(error); env->DeleteLocalRef(msg); env->DeleteLocalRef(cls);
}
void disconnected(std::shared_ptr<Connection> const& current, const wchar_t* message) {
    if (auto owner = current->manager.lock()) owner->call([&](JNIEnv* env) {
        env->CallVoidMethod(owner->callback, owner->disconnected, current->id, text(env, message));
    });
}

struct KnownDevices {
    std::mutex mutex;
    std::map<std::wstring, DeviceInformation> devices;
};
void nameLookupFailed(std::weak_ptr<Manager> const& weak, jlong generation, std::wstring_view message) {
    if (auto owner = weak.lock()) owner->call([&](JNIEnv* env) {
        env->CallVoidMethod(owner->callback, owner->nameLookupFailed, generation, text(env, message));
    });
}
std::pair<hstring, hstring> knownDetails(DeviceInformation const& info) {
    auto properties = info.Properties();
    auto address = properties.HasKey(L"System.Devices.Aep.DeviceAddress") ?
        unbox_value_or<hstring>(properties.Lookup(L"System.Devices.Aep.DeviceAddress"), L"") : hstring{};
    return {address, info.Name()};
}
void publishKnown(std::weak_ptr<Manager> const& weak, jlong generation, std::pair<hstring, hstring> const& details) {
    if (details.first.empty()) return;
    if (auto owner = weak.lock()) owner->call([&](JNIEnv* env) {
        env->CallVoidMethod(owner->callback, owner->knownDevice, generation,
            text(env, details.first.c_str()), text(env, details.second.c_str()));
    });
}

void startNameWatcher(std::shared_ptr<Manager> const& owner, jlong generation) {
    std::weak_ptr<Manager> weak = owner;
    // AEP discovery supplies names Windows already knows, without opening GATT connections.
    auto watcher = DeviceInformation::CreateWatcher(BluetoothLEDevice::GetDeviceSelector(),
        {L"System.Devices.Aep.DeviceAddress"}, DeviceInformationKind::AssociationEndpoint);
    auto known = std::make_shared<KnownDevices>();
    auto added = watcher.Added([weak, known, generation](auto&&, DeviceInformation const& info) {
        try {
            std::pair<hstring, hstring> details;
            { std::lock_guard lock(known->mutex); known->devices.insert_or_assign(std::wstring(info.Id()), info); details = knownDetails(info); }
            publishKnown(weak, generation, details);
        } catch (hresult_error const& e) { nameLookupFailed(weak, generation, e.message().c_str()); }
    });
    auto updated = watcher.Updated([weak, known, generation](auto&&, DeviceInformationUpdate const& update) {
        try {
            std::pair<hstring, hstring> details;
            {
                std::lock_guard lock(known->mutex);
                auto it = known->devices.find(std::wstring(update.Id()));
                if (it == known->devices.end()) return;
                it->second.Update(update);
                details = knownDetails(it->second);
            }
            publishKnown(weak, generation, details);
        } catch (hresult_error const& e) { nameLookupFailed(weak, generation, e.message().c_str()); }
    });
    auto removed = watcher.Removed([known](auto&&, DeviceInformationUpdate const& update) {
        std::lock_guard lock(known->mutex);
        known->devices.erase(std::wstring(update.Id()));
    });
    auto stopped = watcher.Stopped([weak, generation](DeviceWatcher const& sender, auto&&) {
        if (sender.Status() == DeviceWatcherStatus::Aborted) nameLookupFailed(weak, generation, L"Windows device-name discovery aborted");
    });
    {
        std::lock_guard lock(owner->mutex);
        if (owner->closed.load()) throw std::runtime_error("Manager is closed");
        owner->nameWatcher = watcher; owner->addedToken = added; owner->updatedToken = updated;
        owner->removedToken = removed; owner->namesStoppedToken = stopped;
    }
    watcher.Start();
}
DeviceInformation pairingDevice(JNIEnv* env, jstring address, jint type, Clock::time_point limit) {
    auto input = text(env, address);
    input.erase(std::remove(input.begin(), input.end(), L':'), input.end());
    auto numeric = std::stoull(input, nullptr, 16);
    // FindAllAsync(AEP) can wait for radio enumeration even for a known paired device.
    // Resolve the address directly instead. This opens no GATT session and sends no GATT requests.
    struct DeviceScope {
        BluetoothLEDevice value;
        ~DeviceScope() { if (value) try { value.Close(); } catch (...) {} }
    } remote{type == 0 ? await(BluetoothLEDevice::FromBluetoothAddressAsync(numeric), limit) :
        await(BluetoothLEDevice::FromBluetoothAddressAsync(numeric,
            type == 2 ? BluetoothAddressType::Random : BluetoothAddressType::Public), limit)};
    return remote.value ? remote.value.DeviceInformation() : DeviceInformation{nullptr};
}
} // namespace

#define JNI_METHOD(name) Java_dev_gpt_ble_windows_NativeBridge_##name
#define BEGIN try { apartment();
#define END_VALUE(value) } catch (...) { failure(env); return value; }
#define END_VOID } catch (...) { failure(env); }

extern "C" {
JNIEXPORT jlong JNICALL JNI_METHOD(create)(JNIEnv* env, jobject self) { BEGIN
    auto owner = std::make_shared<Manager>();
    env->GetJavaVM(&owner->vm);
    owner->callback = env->NewGlobalRef(self);
    if (!owner->callback) throw std::bad_alloc();
    auto cls = env->GetObjectClass(self);
    owner->advertisement = env->GetMethodID(cls, "onAdvertisement", "(JLjava/lang/String;Ljava/lang/String;IIZZ[Ljava/lang/String;[[B)V");
    owner->scanStopped = env->GetMethodID(cls, "onScanStopped", "(JLjava/lang/String;)V");
    owner->knownDevice = env->GetMethodID(cls, "onKnownDevice", "(JLjava/lang/String;Ljava/lang/String;)V");
    owner->nameLookupFailed = env->GetMethodID(cls, "onNameLookupFailed", "(JLjava/lang/String;)V");
    owner->disconnected = env->GetMethodID(cls, "onDisconnected", "(JLjava/lang/String;)V");
    owner->notification = env->GetMethodID(cls, "onNotification", "(JI[B)V");
    owner->mtuChanged = env->GetMethodID(cls, "onMtuChanged", "(JI)V");
    owner->adapterChanged = env->GetMethodID(cls, "onAdapterStateChanged", "(I)V");
    env->DeleteLocalRef(cls);
    if (env->ExceptionCheck()) return 0;
    auto id = nextId.fetch_add(1);
    { std::lock_guard lock(registryMutex); managers.emplace(id, owner); }
    return id;
END_VALUE(0) }

JNIEXPORT void JNICALL JNI_METHOD(destroy)(JNIEnv* env, jobject, jlong handle) { BEGIN
    std::shared_ptr<Manager> owner;
    { std::lock_guard lock(registryMutex); auto it = managers.find(handle); if (it == managers.end()) return; owner = it->second; managers.erase(it); }
    owner->close();
END_VOID }

JNIEXPORT jint JNICALL JNI_METHOD(adapterState)(JNIEnv* env, jobject, jlong handle) { BEGIN
    auto owner = manager(handle);
    auto limit = deadline();
    auto adapter = await(BluetoothAdapter::GetDefaultAsync(), limit);
    if (!adapter || !adapter.IsLowEnergySupported()) return 3;
    auto radio = await(adapter.GetRadioAsync(), limit);
    if (!radio) return 2;
    {
        std::lock_guard lock(owner->mutex);
        if (!owner->closed.load() && !owner->radio) {
            std::weak_ptr<Manager> weak = owner;
            owner->radio = radio;
            owner->radioToken = radio.StateChanged([weak](Radio const& value, auto&&) {
                if (auto target = weak.lock()) target->call([&](JNIEnv* callbackEnv) {
                    callbackEnv->CallVoidMethod(target->callback, target->adapterChanged, static_cast<jint>(value.State() == RadioState::On ? 0 : 1));
                });
            });
        }
    }
    return radio.State() == RadioState::On ? 0 : 1;
END_VALUE(3) }

JNIEXPORT jint JNICALL JNI_METHOD(pairingState)(JNIEnv* env, jobject, jlong handle, jstring address, jint type) { BEGIN
    auto owner = manager(handle);
    auto info = pairingDevice(env, address, type, deadline());
    if (!info) return -1;
    return info.Pairing().IsPaired() ? 1 : 0;
END_VALUE(-1) }

JNIEXPORT jint JNICALL JNI_METHOD(pair)(JNIEnv* env, jobject, jlong handle, jstring address, jint type, jlong timeout) { BEGIN
    auto owner = manager(handle);
    auto limit = Clock::now() + std::chrono::milliseconds(timeout);
    auto info = pairingDevice(env, address, type, limit);
    if (!info) return -1;
    manager(handle);
    // Basic PairAsync fails with status=Failed for this unpackaged JVM host.
    // Handle only ConfirmOnly: never accept a PIN comparison or supply a PIN implicitly.
    auto pairing = info.Pairing().Custom();
    std::weak_ptr<Manager> weak = owner;
    auto requested = pairing.PairingRequested(auto_revoke,
        [weak](DeviceInformationCustomPairing const&, DevicePairingRequestedEventArgs const& args) {
            if (auto active = weak.lock(); active && !active->closed.load() &&
                args.PairingKind() == DevicePairingKinds::ConfirmOnly) {
                args.Accept();
            }
        });
    auto result = await(pairing.PairAsync(DevicePairingKinds::ConfirmOnly, DevicePairingProtectionLevel::Default), limit);
    return static_cast<jint>(result.Status());
END_VALUE(-1) }

JNIEXPORT jint JNICALL JNI_METHOD(unpair)(JNIEnv* env, jobject, jlong handle, jstring address, jint type, jlong timeout) { BEGIN
    auto owner = manager(handle);
    auto limit = Clock::now() + std::chrono::milliseconds(timeout);
    auto info = pairingDevice(env, address, type, limit);
    if (!info) return -1;
    // Recheck after enumeration before starting the OS mutation.
    manager(handle);
    auto result = await(info.Pairing().UnpairAsync(), limit);
    return static_cast<jint>(result.Status());
END_VALUE(-1) }

JNIEXPORT void JNICALL JNI_METHOD(startScan)(JNIEnv* env, jobject, jlong handle, jlong generation) { BEGIN
    auto owner = manager(handle);
    owner->stop();
    BluetoothLEAdvertisementWatcher watcher;
    watcher.ScanningMode(BluetoothLEScanningMode::Active);
    std::weak_ptr<Manager> weak = owner;
    auto received = watcher.Received([weak, generation](auto&&, BluetoothLEAdvertisementReceivedEventArgs const& args) {
        auto target = weak.lock();
        if (!target) return;
        target->call([&](JNIEnv* callbackEnv) {
            auto advertisement = args.Advertisement();
            std::vector<std::wstring> uuids;
            for (auto const& item : advertisement.ServiceUuids()) uuids.push_back(uuid(item));
            // Service Data AD types include their own service UUID, even without a UUID list.
            for (auto const& section : advertisement.DataSections()) {
                const auto type = section.DataType();
                auto data = bytes(section.Data());
                if (type == 0x16 && data.size() >= 2) {
                    guid value{static_cast<uint32_t>(data[0] | data[1] << 8), 0, 0x1000, {0x80,0,0,0x80,0x5f,0x9b,0x34,0xfb}};
                    uuids.push_back(uuid(value));
                } else if (type == 0x20 && data.size() >= 4) {
                    uint32_t first = static_cast<uint32_t>(data[0]) | static_cast<uint32_t>(data[1]) << 8 | static_cast<uint32_t>(data[2]) << 16 | static_cast<uint32_t>(data[3]) << 24;
                    guid value{first, 0, 0x1000, {0x80,0,0,0x80,0x5f,0x9b,0x34,0xfb}};
                    uuids.push_back(uuid(value));
                } else if (type == 0x21 && data.size() >= 16) {
                    wchar_t full[37];
                    swprintf_s(full, L"%02x%02x%02x%02x-%02x%02x-%02x%02x-%02x%02x-%02x%02x%02x%02x%02x%02x",
                        data[15],data[14],data[13],data[12],data[11],data[10],data[9],data[8],data[7],data[6],data[5],data[4],data[3],data[2],data[1],data[0]);
                    uuids.emplace_back(full);
                }
            }
            auto arrayClass = callbackEnv->FindClass("[B");
            auto manufacturers = advertisement.ManufacturerData();
            auto manufacturerArray = callbackEnv->NewObjectArray(static_cast<jsize>(manufacturers.Size()), arrayClass, nullptr);
            for (uint32_t i = 0; i < manufacturers.Size(); ++i) {
                auto entry = manufacturers.GetAt(i);
                std::vector<uint8_t> data{static_cast<uint8_t>(entry.CompanyId() & 255), static_cast<uint8_t>(entry.CompanyId() >> 8)};
                auto payload = bytes(entry.Data()); data.insert(data.end(), payload.begin(), payload.end());
                auto item = byteArray(callbackEnv, data);
                callbackEnv->SetObjectArrayElement(manufacturerArray, static_cast<jsize>(i), item);
                callbackEnv->DeleteLocalRef(item);
            }
            const auto type = args.AdvertisementType();
            const bool connectable = type == BluetoothLEAdvertisementType::ConnectableUndirected || type == BluetoothLEAdvertisementType::ConnectableDirected;
            const auto addressType = args.BluetoothAddressType();
            const jint addressKind = addressType == BluetoothAddressType::Public ? 1 : addressType == BluetoothAddressType::Random ? 2 : 0;
            auto name = advertisement.LocalName();
            const bool complete = advertisement.GetSectionsByType(BluetoothLEAdvertisementDataTypes::CompleteLocalName()).Size() > 0;
            callbackEnv->CallVoidMethod(target->callback, target->advertisement, generation,
                text(callbackEnv, addressString(args.BluetoothAddress())), name.empty() ? nullptr : text(callbackEnv, name.c_str()),
                static_cast<jint>(args.RawSignalStrengthInDBm()), addressKind, static_cast<jboolean>(connectable),
                static_cast<jboolean>(complete), strings(callbackEnv, uuids), manufacturerArray);
        });
    });
    auto stopped = watcher.Stopped([weak, generation](auto&&, BluetoothLEAdvertisementWatcherStoppedEventArgs const& args) {
        if (auto target = weak.lock()) target->call([&](JNIEnv* callbackEnv) {
            auto message = L"Windows scan stopped, error=" + std::to_wstring(static_cast<int>(args.Error()));
            callbackEnv->CallVoidMethod(target->callback, target->scanStopped, generation,
                args.Error() == BluetoothError::Success ? nullptr : text(callbackEnv, message));
        });
    });
    {
        std::lock_guard lock(owner->mutex);
        if (owner->closed.load()) throw std::runtime_error("Manager is closed");
        owner->watcher = watcher; owner->receivedToken = received; owner->stoppedToken = stopped;
    }
    watcher.Start();
    try { startNameWatcher(owner, generation); }
    catch (hresult_error const& e) { nameLookupFailed(weak, generation, e.message().c_str()); }
    catch (std::exception const& e) { nameLookupFailed(weak, generation, to_hstring(e.what()).c_str()); }
END_VOID }

JNIEXPORT void JNICALL JNI_METHOD(stopScan)(JNIEnv* env, jobject, jlong handle) { BEGIN
    manager(handle)->stop();
END_VOID }

JNIEXPORT jlong JNICALL JNI_METHOD(connect)(JNIEnv* env, jobject, jlong handle, jstring address, jint type, jlong timeout) { BEGIN
    auto owner = manager(handle);
    auto input = text(env, address);
    input.erase(std::remove(input.begin(), input.end(), L':'), input.end());
    auto numeric = std::stoull(input, nullptr, 16);
    auto limit = Clock::now() + std::chrono::milliseconds(timeout);
    auto current = std::make_shared<Connection>();
    current->id = nextId.fetch_add(1);
    current->manager = owner;
    current->device = type == 0 ? await(BluetoothLEDevice::FromBluetoothAddressAsync(numeric), limit) :
        await(BluetoothLEDevice::FromBluetoothAddressAsync(numeric, type == 2 ? BluetoothAddressType::Random : BluetoothAddressType::Public), limit);
    if (!current->device) throw std::runtime_error("Windows cannot resolve this BLE address; scan for it first");
    current->session = await(GattSession::FromDeviceIdAsync(current->device.BluetoothDeviceId()), limit);
    if (!current->session) throw std::runtime_error("Windows could not create a GATT session");
    current->session.MaintainConnection(true);
    auto result = await(current->device.GetGattServicesAsync(BluetoothCacheMode::Uncached), limit);
    success(result.Status());
    for (auto const& service : result.Services()) current->services.push_back(service);
    if (current->device.ConnectionStatus() != BluetoothConnectionStatus::Connected) throw std::runtime_error("Device is not connected");
    {
        std::lock_guard lock(owner->mutex);
        if (owner->closed.load()) throw std::runtime_error("Manager was closed during connection");
        owner->connections.emplace(current->id, current);
    }
    return current->id;
END_VALUE(0) }

JNIEXPORT jboolean JNICALL JNI_METHOD(monitor)(JNIEnv* env, jobject, jlong handle, jlong id) { BEGIN
    auto current = connection(handle, id);
    std::weak_ptr<Connection> weak = current;
    auto status = current->device.ConnectionStatusChanged([weak](BluetoothLEDevice const& device, auto&&) {
        if (auto value = weak.lock(); value && !value->closed.load() && device.ConnectionStatus() == BluetoothConnectionStatus::Disconnected) {
            disconnected(value, L"Remote device disconnected");
        }
    });
    auto changed = current->device.GattServicesChanged([weak](auto&&, auto&&) {
        // Windows raises this while populating the first uncached GATT catalog.
        // There are no published handles to invalidate until discovery completes.
        if (auto value = weak.lock(); value && !value->closed.load() && value->catalogReady.load()) disconnected(value, L"GATT database changed; reconnect to rediscover handles");
    });
    auto mtuToken = current->session.MaxPduSizeChanged([weak](GattSession const& session, auto&&) {
        auto value = weak.lock();
        if (!value || value->closed.load()) return;
        if (auto owner = value->manager.lock()) owner->call([&](JNIEnv* callbackEnv) {
            callbackEnv->CallVoidMethod(owner->callback, owner->mtuChanged, value->id, static_cast<jint>(session.MaxPduSize()));
        });
    });
    {
        std::lock_guard lock(current->mutex);
        if (!current->closed.load()) { current->statusToken = status; current->servicesToken = changed; current->mtuToken = mtuToken; }
        else { current->device.ConnectionStatusChanged(status); current->device.GattServicesChanged(changed); current->session.MaxPduSizeChanged(mtuToken); return JNI_FALSE; }
    }
    return current->device.ConnectionStatus() == BluetoothConnectionStatus::Connected ? JNI_TRUE : JNI_FALSE;
END_VALUE(JNI_FALSE) }

JNIEXPORT void JNICALL JNI_METHOD(disconnect)(JNIEnv* env, jobject, jlong handle, jlong id) { BEGIN
    auto owner = manager(handle);
    std::shared_ptr<Connection> current;
    {
        std::lock_guard lock(owner->mutex);
        auto it = owner->connections.find(id); if (it == owner->connections.end()) return;
        current = it->second; owner->connections.erase(it);
    }
    current->close();
END_VOID }

JNIEXPORT jbyteArray JNICALL JNI_METHOD(readDeviceName)(JNIEnv* env, jobject, jlong handle, jlong id) { BEGIN
    auto current = connection(handle, id);
    std::vector<GattDeviceService> services;
    { std::lock_guard lock(current->mutex); services = current->services; }
    const guid genericAccess{0x1800, 0, 0x1000, {0x80,0,0,0x80,0x5f,0x9b,0x34,0xfb}};
    const guid deviceName{0x2a00, 0, 0x1000, {0x80,0,0,0x80,0x5f,0x9b,0x34,0xfb}};
    auto limit = deadline();
    for (auto const& service : services) {
        if (service.Uuid() != genericAccess) continue;
        auto chars = await(service.GetCharacteristicsForUuidAsync(deviceName, BluetoothCacheMode::Uncached), limit);
        success(chars.Status(), "Find Generic Access / Device Name");
        for (auto const& characteristic : chars.Characteristics()) {
            if ((characteristic.CharacteristicProperties() & GattCharacteristicProperties::Read) == GattCharacteristicProperties::None) continue;
            auto value = await(characteristic.ReadValueAsync(BluetoothCacheMode::Uncached), limit);
            success(value.Status(), "Read Generic Access / Device Name");
            return byteArray(env, bytes(value.Value()));
        }
    }
    return nullptr;
END_VALUE(nullptr) }

JNIEXPORT jobjectArray JNICALL JNI_METHOD(discover)(JNIEnv* env, jobject, jlong handle, jlong id) { BEGIN
    auto current = connection(handle, id);
    std::vector<GattDeviceService> services;
    { std::lock_guard lock(current->mutex); services = current->services; }
    std::vector<std::wstring> records;
    std::map<int, GattCharacteristic> characteristics;
    std::map<int, GattDescriptor> descriptors;
    auto limit = deadline();
    for (auto const& service : services) {
        auto serviceId = std::to_wstring(service.AttributeHandle());
        records.push_back(L"S|" + serviceId + L"|" + uuid(service.Uuid()));
        auto chars = await(service.GetCharacteristicsAsync(BluetoothCacheMode::Uncached), limit);
        success(chars.Status(), "Discover characteristics for service " + to_string(uuid(service.Uuid())));
        for (auto const& characteristic : chars.Characteristics()) {
            int charHandle = characteristic.AttributeHandle();
            auto charId = std::to_wstring(charHandle);
            records.push_back(L"C|" + serviceId + L"|" + charId + L"|" + uuid(characteristic.Uuid()) + L"|" + std::to_wstring(static_cast<int>(characteristic.CharacteristicProperties())));
            characteristics.emplace(charHandle, characteristic);
            auto descs = await(characteristic.GetDescriptorsAsync(BluetoothCacheMode::Uncached), limit);
            success(descs.Status(), "Discover descriptors for characteristic " + to_string(uuid(characteristic.Uuid())));
            for (auto const& desc : descs.Descriptors()) {
                int descHandle = desc.AttributeHandle();
                records.push_back(L"D|" + charId + L"|" + std::to_wstring(descHandle) + L"|" + uuid(desc.Uuid()));
                descriptors.emplace(descHandle, desc);
            }
        }
    }
    {
        std::lock_guard lock(current->mutex);
        if (current->closed.load()) throw std::runtime_error("Connection ended during discovery");
        current->characteristics = std::move(characteristics); current->descriptors = std::move(descriptors);
        current->catalogReady.store(true);
    }
    return strings(env, records);
END_VALUE(nullptr) }

JNIEXPORT jbyteArray JNICALL JNI_METHOD(read)(JNIEnv* env, jobject, jlong handle, jlong id, jint attribute, jboolean descriptor) { BEGIN
    auto current = connection(handle, id);
    GattReadResult result{nullptr};
    if (descriptor) {
        GattDescriptor target{nullptr}; { std::lock_guard lock(current->mutex); target = current->descriptors.at(attribute); }
        result = await(target.ReadValueAsync(BluetoothCacheMode::Uncached), deadline());
    } else {
        GattCharacteristic target{nullptr}; { std::lock_guard lock(current->mutex); target = current->characteristics.at(attribute); }
        result = await(target.ReadValueAsync(BluetoothCacheMode::Uncached), deadline());
    }
    success(result.Status());
    return byteArray(env, bytes(result.Value()));
END_VALUE(nullptr) }

JNIEXPORT void JNICALL JNI_METHOD(write)(JNIEnv* env, jobject, jlong handle, jlong id, jint attribute, jboolean descriptor, jbyteArray data, jboolean response) { BEGIN
    auto current = connection(handle, id);
    auto value = buffer(env, data);
    if (descriptor) {
        GattDescriptor target{nullptr}; { std::lock_guard lock(current->mutex); target = current->descriptors.at(attribute); }
        success(await(target.WriteValueAsync(value), deadline()));
    } else {
        GattCharacteristic target{nullptr}; { std::lock_guard lock(current->mutex); target = current->characteristics.at(attribute); }
        success(await(target.WriteValueAsync(value, response ? GattWriteOption::WriteWithResponse : GattWriteOption::WriteWithoutResponse), deadline()));
    }
END_VOID }

JNIEXPORT void JNICALL JNI_METHOD(subscribe)(JNIEnv* env, jobject, jlong handle, jlong id, jint attribute, jint mode) { BEGIN
    auto current = connection(handle, id);
    GattCharacteristic characteristic{nullptr};
    bool registered = false;
    { std::lock_guard lock(current->mutex); characteristic = current->characteristics.at(attribute); registered = current->notifications.contains(attribute); }
    event_token fresh{};
    if (mode != 0 && !registered) {
        std::weak_ptr<Connection> weak = current;
        fresh = characteristic.ValueChanged([weak, attribute](auto&&, GattValueChangedEventArgs const& args) {
            auto value = weak.lock(); if (!value || value->closed.load()) return;
            if (auto owner = value->manager.lock()) owner->call([&](JNIEnv* callbackEnv) {
                callbackEnv->CallVoidMethod(owner->callback, owner->notification, value->id, attribute, byteArray(callbackEnv, bytes(args.CharacteristicValue())));
            });
        });
    }
    try {
        auto setting = mode == 0 ? GattClientCharacteristicConfigurationDescriptorValue::None :
            mode == 1 ? GattClientCharacteristicConfigurationDescriptorValue::Notify : GattClientCharacteristicConfigurationDescriptorValue::Indicate;
        success(await(characteristic.WriteClientCharacteristicConfigurationDescriptorAsync(setting), deadline()));
    } catch (...) { if (fresh.value) characteristic.ValueChanged(fresh); throw; }
    event_token remove{};
    {
        std::lock_guard lock(current->mutex);
        if (current->closed.load()) remove = fresh;
        else if (mode == 0 && registered) { remove = current->notifications.at(attribute).second; current->notifications.erase(attribute); }
        else if (fresh.value) current->notifications.emplace(attribute, std::make_pair(characteristic, fresh));
    }
    if (remove.value) characteristic.ValueChanged(remove);
END_VOID }

JNIEXPORT jint JNICALL JNI_METHOD(mtu)(JNIEnv* env, jobject, jlong handle, jlong id) { BEGIN
    return connection(handle, id)->session.MaxPduSize();
END_VALUE(23) }
} // extern C
